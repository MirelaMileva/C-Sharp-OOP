﻿namespace Person
{
    internal class vitrual
    {
    }
}