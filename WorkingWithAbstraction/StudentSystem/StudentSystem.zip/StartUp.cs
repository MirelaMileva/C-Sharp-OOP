﻿using System;

namespace StudentSystem
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Process();
        }
    }
}
